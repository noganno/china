#SXD20|20010|50163|50313|2013.07.17 15:56:58|china|0|5|17|
#TA tbl_comment`1`16384|tbl_lookup`7`16384|tbl_post`5`16384|tbl_tag`3`16384|tbl_user`1`16384
#EOH

#	TC`tbl_comment`utf8_unicode_ci	;
CREATE TABLE `tbl_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `author` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_comment_post` (`post_id`),
  CONSTRAINT `FK_comment_post` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`tbl_comment`utf8_unicode_ci	;
INSERT INTO `tbl_comment` VALUES 
(1,'This is a test comment.',2,1230952187,'Tester','tester@example.com',\N,2)	;
#	TC`tbl_lookup`utf8_unicode_ci	;
CREATE TABLE `tbl_lookup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`tbl_lookup`utf8_unicode_ci	;
INSERT INTO `tbl_lookup` VALUES 
(1,'Draft',1,'PostStatus',1),
(2,'Published',2,'PostStatus',2),
(3,'Archived',3,'PostStatus',3),
(4,'Pending Approval',1,'CommentStatus',1),
(5,'Approved',2,'CommentStatus',2),
(6,'R/E',1,'StatusOrder',1),
(7,'R',2,'StatusOrder',2)	;
#	TC`tbl_post`utf8_unicode_ci	;
CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `tags` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `url_good` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  `weith` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `re` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_post_author` (`author_id`),
  CONSTRAINT `FK_post_author` FOREIGN KEY (`author_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`tbl_post`utf8_unicode_ci	;
INSERT INTO `tbl_post` VALUES 
(1,'Welcome!','This blog system is developed using Yii. It is meant to demonstrate how to use Yii to build a complete real-world application. Complete source code may be found in the Yii releases.\r\n\r\nFeel free to try this system by writing new posts and posting comments.','yii, blog',2,1230952187,1230952187,1,'','','',0,'',''),
(2,'A Test Post','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','test',2,1230952187,1230952187,1,'','','',0,'',''),
(3,'post1','text1','',1,1374057253,1374057253,1,'','','',0,'',''),
(4,'12312','asdasdasd','',1,1374059054,1374059054,1,'12312','','',0,'',''),
(5,'Генерируем выпадающий список','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum. Vivamus sit amet libero turpis, non venenatis urna. In blandit, odio convallis suscipit venenatis, ante ipsum cursus augue.\r\n','',1,1374060130,1374060824,1,'http://www.dbhelp.ru/by-example-chtml-dropdownlist/page/','','10',2,'','2')	;
#	TC`tbl_tag`utf8_unicode_ci	;
CREATE TABLE `tbl_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `frequency` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`tbl_tag`utf8_unicode_ci	;
INSERT INTO `tbl_tag` VALUES 
(1,'yii',1),
(2,'blog',1),
(3,'test',1)	;
#	TC`tbl_user`utf8_unicode_ci	;
CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `profile` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`tbl_user`utf8_unicode_ci	;
INSERT INTO `tbl_user` VALUES 
(1,'demo','$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC','webmaster@example.com',\N)	;
