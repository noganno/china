#SXD20|20010|50610|50217|2013.07.25 07:43:40|chinadmin|0|7|110|
#TA dev_category`12`556|dev_comments`2`196|dev_content`9`2912|dev_filescounter`1`44|dev_settings`61`2344|dev_statistic`24`5532|dev_user`1`52
#EOH

#	TC`dev_category`utf8_general_ci	;
CREATE TABLE `dev_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias_cat` varchar(255) NOT NULL,
  `position` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8	;
#	TD`dev_category`utf8_general_ci	;
INSERT INTO `dev_category` VALUES 
(1,'Общая','/','2'),
(16,'Оплаченные','payed','15'),
(6,'Не оплаченные','notpaid','1'),
(7,'В обработке','Processing','2'),
(8,'Доставлено','Shipped','3'),
(9,'Отменено','Canceled','4'),
(10,'Отправлен','Complete','5'),
(11,'Отмена и аннулирование','Canceled Reversal','7'),
(12,'Неудавшийся','Failed','8'),
(13,'Ожидание','Pending','9'),
(14,'Обработан','Processed','11'),
(15,'Просрочен','Expired','12')	;
#	TC`dev_comments`utf8_general_ci	;
CREATE TABLE `dev_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `material_id` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_website` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8	;
#	TD`dev_comments`utf8_general_ci	;
INSERT INTO `dev_comments` VALUES 
(32,'Тестовый камент',3,1373791526,0,'Никита','admin@admin.com',''),
(34,'Тестовый камент 2',3,1373786189,0,'Сергей(администратор)','info@q-seo.ru','q-seo.ru')	;
#	TC`dev_content`utf8_general_ci	;
CREATE TABLE `dev_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `introtext` text,
  `content` text,
  `alias` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `uri` varchar(255) NOT NULL,
  `created` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `count` varchar(255) NOT NULL,
  `re` varchar(255) NOT NULL,
  `link` varchar(1000) NOT NULL,
  `img` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`dev_content`utf8_general_ci	;
INSERT INTO `dev_content` VALUES 
(1,'Yii  - The Fast, Secure and Professional PHP Framework ','4',' <h2>\r\nYii is a\r\n<a href=\"/performance/\">high-performance</a>\r\nPHP framework best for developing Web 2.0 applications.\r\n</h2>','yii-framework.html','Опубликована','Опубликована','/content/yii-framework.html',345436456,1,4,'','','','','0'),
(2,'Контакты','Адрес','<p> Адрес: 123242, Россия, Москва, Большой Предтеченский переулок, д. ...</p>\r\n<p>Секретарь - Тел.: (499) 999-999-999,  Факс: (499) 9999-9999-9999 </p>','contacts','','','/contacts',1371715980,1,1,'','','','','0'),
(3,'О нашей компании','333','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\n	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\n	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\n	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\n	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\n	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>	','aboutus','3333334545346','46456457567','/content/aboutus',1371902918,1,4,'','','','','0'),
(4,'Главная','5','<p>Контент главной страницы</p>\r\n<p>Показ  заголовка отключен в контроллере</p>','/','','','/',1371905700,1,1,'','','','','0'),
(5,'Продукция','1','Проду́кция — термин, характеризующий результат производственной, хозяйственной деятельности. Представляет собой совокупность продуктов, явившихся результатом производства отдельного предприятия, отрасли промышленности','product','','','/product',1371922804,1,1,'','','','','0'),
(6,'sdfsdfsdfsdf','ываыв fsdf sdf','ыва ыва sdf','12312123','123 123 123 1','23123 123 123','//Processing/12312123',1374148253,0,7,'123123','123','','','0'),
(7,'dsdsf','dsdf','sdfsdfsdfdsfdfsdfsfsfs','sdfsdfsdf','','','/sdfsdfsdf',1374301894,0,1,'','','','http://item.taobao.com/item.htm?spm=a230r.1.14.10.iBpyKv&id=19832983608','0'),
(8,'品牌特卖 瑞西屋正品 特价印花多功能珊瑚绒毯 秋冬懒人毯','asdasd asd asd sd',\N,'1111111',\N,\N,'/Processing/1111111',1374312540,0,7,'158.00','12','','http://item.taobao.com/item.htm?spm=a230r.1.14.10.iBpyKv&id=19832983608','http://img04.taobaocdn.com/bao/uploaded/i4/19231023539558842/T16yqtXxVfXXXXXXXX_!!0-item_pic.jpg_310x310.jpg'),
(9,'美织雪2013新款中老年短袖蕾丝衫 韩版蕾丝修身妈妈装荷叶边衬衣','какая то аннотация',\N,'1111111',\N,\N,'/Processing/1111111',1374405639,0,7,'98.00','1','','http://item.taobao.com/item.htm?spm=a2106.m874.0.0.IU3Dhd&id=20394071159&&scm=1029.personallist-43.0.50000852&ppath=&sku=','http://img02.taobaocdn.com/bao/uploaded/i2/11098024797323997/T1QJ9yXsVfXXXXXXXX_!!0-item_pic.jpg_310x310.jpg')	;
#	TC`dev_filescounter`utf8_general_ci	;
CREATE TABLE `dev_filescounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `remote_addr` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`dev_filescounter`utf8_general_ci	;
INSERT INTO `dev_filescounter` VALUES 
(1,'проверка','93.170.76.57',1372081911)	;
#	TC`dev_settings`utf8_general_ci	;
CREATE TABLE `dev_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8	;
#	TD`dev_settings`utf8_general_ci	;
INSERT INTO `dev_settings` VALUES 
(1,'siteurl','http://chinadmin'),
(2,'sitename','Название сайта'),
(129,'company_name','Моя компания'),
(5,'admin_email','admin@admin'),
(18,'default_comment_status','open'),
(19,'default_ping_status','open'),
(20,'default_pingback_flag','1'),
(132,'slogan','Текст слогана'),
(133,'social_text','Текст для заголовка в социальных кнопках'),
(31,'gzipcompression','0'),
(32,'hack_file','0'),
(33,'blog_charset','UTF-8'),
(34,'moderation_keys',''),
(35,'active_plugins','a:0:{}'),
(36,'home','http://example.com'),
(37,'category_base',''),
(38,'ping_sites','http://rpc.pingomatic.com/'),
(39,'advanced_edit','0'),
(40,'comment_max_links','2'),
(41,'gmt_offset','4'),
(42,'default_email_category','1'),
(43,'recently_edited',''),
(44,'template','bootstrap'),
(45,'stylesheet','bootstrap'),
(46,'comment_whitelist','1'),
(47,'blacklist_keys',''),
(48,'comment_registration','0'),
(49,'html_type','text/html'),
(50,'use_trackback','0'),
(51,'default_role','subscriber'),
(52,'db_version','22441'),
(53,'uploads_use_yearmonth_folders','1'),
(54,'upload_path',''),
(55,'blog_public','1'),
(56,'default_link_category','2'),
(57,'show_on_front','posts'),
(58,'tag_base',''),
(59,'show_avatars','1'),
(60,'avatar_rating','G'),
(61,'upload_url_path',''),
(62,'thumbnail_size_w','150'),
(63,'thumbnail_size_h','150'),
(64,'thumbnail_crop','1'),
(65,'medium_size_w','300'),
(66,'medium_size_h','300'),
(67,'avatar_default','mystery'),
(68,'large_size_w','1024'),
(69,'large_size_h','1024'),
(70,'image_default_link_type','file'),
(71,'image_default_size',''),
(72,'image_default_align',''),
(73,'close_comments_for_old_posts','0'),
(74,'close_comments_days_old','14'),
(75,'thread_comments','1'),
(76,'thread_comments_depth','5'),
(77,'page_comments','0'),
(78,'comments_per_page','50'),
(79,'default_comments_page','newest'),
(80,'comment_order','asc'),
(130,'add_to_title','Дополнение в заголовок'),
(131,'charset','GBK')	;
#	TC`dev_statistic`latin1_swedish_ci	;
CREATE TABLE `dev_statistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` text CHARACTER SET utf8,
  `date` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1	;
#	TD`dev_statistic`latin1_swedish_ci	;
INSERT INTO `dev_statistic` VALUES 
(1,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374128040),
(2,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374128190),
(3,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/\",\"uri\":\"http:\\/\\/chinadmin\\/contacts\"}',1374128201),
(4,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/contacts\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374128206),
(5,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/admin\"}',1374128210),
(6,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/admin\",\"uri\":\"http:\\/\\/chinadmin\\/content\\/aboutus\"}',1374128218),
(7,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/content\\/aboutus\",\"uri\":\"http:\\/\\/chinadmin\\/content\\/sitemap.xml\"}',1374128230),
(8,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374293964),
(9,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/\",\"uri\":\"http:\\/\\/chinadmin\\/content\\/aboutus\"}',1374293977),
(10,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/content\\/aboutus\",\"uri\":\"http:\\/\\/chinadmin\\/contacts\"}',1374293980),
(11,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/contacts\",\"uri\":\"http:\\/\\/chinadmin\\/site\\/feedbackform\"}',1374293984),
(12,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko\\/20100101 Firefox\\/22.0\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/site\\/login\"}',1374298509),
(13,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374389148),
(14,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374389355),
(15,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374389774),
(16,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374389786),
(17,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/\",\"uri\":\"http:\\/\\/chinadmin\\/contacts\"}',1374389794),
(18,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/contacts\",\"uri\":\"http:\\/\\/chinadmin\\/content\\/aboutus\"}',1374389796),
(19,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/content\\/aboutus\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374389802),
(20,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/\",\"uri\":\"http:\\/\\/chinadmin\\/content\\/aboutus\"}',1374389813),
(21,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/\",\"uri\":\"http:\\/\\/chinadmin\\/content\\/aboutus\"}',1374390035),
(22,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/content\\/aboutus\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374390037),
(23,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/content\\/aboutus\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374390039),
(24,'{\"ip\":\"127.0.0.1\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/28.0.1500.72 Safari\\/537.36\",\"UrlReferrer\":\"http:\\/\\/chinadmin\\/content\\/aboutus\",\"uri\":\"http:\\/\\/chinadmin\\/\"}',1374390050)	;
#	TC`dev_user`utf8_general_ci	;
CREATE TABLE `dev_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created` int(11) NOT NULL,
  `ban` tinyint(1) NOT NULL,
  `role` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`dev_user`utf8_general_ci	;
INSERT INTO `dev_user` VALUES 
(1,'admin','0c7540eb7e65b553ec1ba6b20de79608',465645767,0,5)	;
